#include <stdio.h>

int main() {
    float operation1 = 35/5;
    printf("Operation 1 is: %f\n", operation1 );
    float operation2 = 36/7;
    printf("Operation 2 is: %f\n", operation2);
    float operation3 = 18-32/6*3;
    printf("Operation 3 is: %f\n", operation3);
    float operation4 = 220/5;
    printf("Operation 4 is: %f\n", operation4);
    float operation5 = 27-7%3+8/3;
    printf("Operation 5 is: %f\n", operation5);



    return 0;
}


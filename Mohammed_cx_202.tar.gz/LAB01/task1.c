#include <stdio.h>

int main() {
	char Mohammed = 77; //M
	printf("%c", Mohammed);


	Mohammed = Mohammed + 34; //o
	printf("%c", Mohammed);

	Mohammed = Mohammed - 7; //h
	printf("%c", Mohammed);

	Mohammed = Mohammed -7; //a
	printf("%c", Mohammed);

	Mohammed = Mohammed + 12; //m
	printf("%c", Mohammed);

	 
        printf("%c", Mohammed); //m


	Mohammed = Mohammed - 8; //e
	printf("%c", Mohammed);

	char d = 'd';
       	printf("%c\n", d);





        char num = 56;
        printf("%c", num);

        num = 48;
        printf("%c", num);

	num = 55;
	printf("%c", num);

	char last = '4';
	printf("%c\n", last);
	return 0;









}


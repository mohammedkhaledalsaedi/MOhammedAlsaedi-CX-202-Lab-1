#include <stdio.h>

int main() {
    int numCourses;
    float totalPoints = 0.0;
    int totalCredits = 0;

    printf("Enter the number of courses: ");
    scanf("%d", &numCourses);

    for (int i = 0; i < numCourses; i++) {
        int credits;
        float grade;

        printf("Enter credit hours for course %d: ", i + 1);
        scanf("%d", &credits);
        printf("Enter grade for course %d (1.0 or 1.5 or 2.0 or 2.5 or 3.0 or 3.5 or 4.0): ", i + 1);
        scanf("%f", &grade);

        totalPoints += grade * credits;
        totalCredits += credits;
    }

    float gpa;
    if (totalCredits > 0) {
        gpa = totalPoints / totalCredits;
    } else {
        gpa = 0.0;
    }

    printf("Your GPA is: %.2f\n", gpa);

    return 0;
}


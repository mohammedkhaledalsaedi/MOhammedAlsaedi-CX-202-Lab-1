#include <stdio.h>

int main() {

    float R1 = 0.0;
    float R2 = 0.0;
    float R3 = 0.0;
    float supply = 0.0;
    float voltage2;

    printf("Enter the value of R1: ");
    scanf("%f", &R1);

    printf("Enter the value of R2: ");
    scanf("%f", &R2);

    printf("Enter the value of R3: ");
    scanf("%f", &R3);

    printf("Enter the value of the voltage supply: ");
    scanf("%f", &supply);

    voltage2 = ((R2 * R3) / (R2 + R3)) / (R1 + ((R2 * R3) / (R2 + R3))) * supply;

    float i2 = voltage2 / R2;
    printf("The value of i2 is: %f A\n", i2);

    float i3 = voltage2 / R3;
    printf("The value of i3 is: %f A\n", i3);

    float i1 = i2 + i3;
    printf("The value of i1 is: %f A\n", i1);

    return 0;
}


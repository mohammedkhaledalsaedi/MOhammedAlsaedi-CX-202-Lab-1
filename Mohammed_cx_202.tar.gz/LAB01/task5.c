#include <stdio.h>

int main() {
    float mass1;
    float mass2;
    double distance;
    double k = 6.67e-8;
    double g;

    
    printf("Enter the mass of the first object: ");
    scanf("%f", &mass1);

    printf("Enter the mass of the second object: ");
    scanf("%f", &mass2);

    printf("Enter the distance between the two objects: ");
    scanf("%lf", &distance);

    
    g = k * ((mass1 * mass2) / (distance * distance));


    printf("The gravitational force is: %e N\n", g);

    return 0;
}

